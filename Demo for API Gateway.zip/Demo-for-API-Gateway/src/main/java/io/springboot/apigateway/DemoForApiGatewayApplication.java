package io.springboot.apigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoForApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoForApiGatewayApplication.class, args);
	}

}
